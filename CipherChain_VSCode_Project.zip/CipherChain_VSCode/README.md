# CipherChain — VS Code project

## Run on Windows
1. Install Python 3.10+ and VS Code.
2. Extract this folder and open it in VS Code (`File > Open Folder`).
3. Open `Terminal > New Terminal`.
4. Run:

```powershell
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

If PowerShell blocks environment activation, use Command Prompt terminal and run:
`.venv\Scripts\activate.bat`

5. Open http://127.0.0.1:5000
6. Register two accounts to test sending and receiving messages.

## Features
- Flask web app and responsive interface
- User registration/login with password hashing
- AES-GCM message encryption
- SHA-256 hash-linked local ledger
- Ledger integrity verification
- JSON storage created automatically in `data/`

## Important limitations
This is an educational prototype. Its ledger is a local JSON file, not a decentralized blockchain network. The encryption key is derived on the server, so it is not true end-to-end encryption. Do not use for sensitive messages or deploy publicly as-is. For a production design, implement client-side key generation and a reviewed key-exchange protocol, HTTPS, CSRF protection, hardened sessions, a database, and a real distributed ledger/smart contract.
