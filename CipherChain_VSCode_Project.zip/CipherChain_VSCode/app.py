import os
import json
import time
import hashlib
import secrets
from pathlib import Path
from functools import wraps

from flask import Flask, request, redirect, url_for, session, flash, render_template_string
from werkzeug.security import generate_password_hash, check_password_hash
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
USERS_FILE = DATA_DIR / "users.json"
CHAIN_FILE = DATA_DIR / "chain.json"

app = Flask(__name__)
# Set CIPHERCHAIN_SECRET in your environment for anything beyond a local demo.
app.secret_key = os.environ.get("CIPHERCHAIN_SECRET", "local-demo-secret-change-before-deployment")


def read_json(path, fallback):
    if not path.exists():
        return fallback
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return fallback


def write_json(path, data):
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    temp.replace(path)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def block_hash(block):
    return sha256(canonical({key: value for key, value in block.items() if key != "hash"}))


def get_chain():
    chain = read_json(CHAIN_FILE, [])
    if not chain:
        genesis = {
            "index": 0, "timestamp": time.time(), "sender": "SYSTEM",
            "recipient": "SYSTEM", "nonce": "", "ciphertext": "",
            "previous_hash": "0" * 64
        }
        genesis["hash"] = block_hash(genesis)
        chain = [genesis]
        write_json(CHAIN_FILE, chain)
    return chain


def add_block(sender, recipient, nonce, ciphertext):
    chain = get_chain()
    block = {
        "index": len(chain),
        "timestamp": time.time(),
        "sender": sender,
        "recipient": recipient,
        "nonce": nonce,
        "ciphertext": ciphertext,
        "previous_hash": chain[-1]["hash"],
    }
    block["hash"] = block_hash(block)
    chain.append(block)
    write_json(CHAIN_FILE, chain)
    return block


def verify_chain(chain=None):
    chain = chain if chain is not None else get_chain()
    if not chain:
        return False, "Chain is empty."
    for i, block in enumerate(chain):
        if block.get("index") != i:
            return False, f"Block index mismatch at block {i}."
        if block.get("hash") != block_hash(block):
            return False, f"Block {i} hash mismatch."
        expected_previous = "0" * 64 if i == 0 else chain[i - 1].get("hash")
        if block.get("previous_hash") != expected_previous:
            return False, f"Block {i} previous-hash mismatch."
    return True, f"All {len(chain)} blocks passed integrity checks."


def make_demo_key(sender, recipient):
    # Educational demo only: server-side shared key is NOT true end-to-end encryption.
    master = os.environ.get("CIPHERCHAIN_DEMO_KEY", "local-demo-only-key-change-me")
    identity = ":".join(sorted([sender, recipient]))
    return hashlib.sha256(f"CipherChain:{master}:{identity}".encode()).digest()


def encrypt_message(sender, recipient, message):
    key = make_demo_key(sender, recipient)
    nonce = secrets.token_bytes(12)
    aad = f"{sender}:{recipient}".encode()
    ciphertext = AESGCM(key).encrypt(nonce, message.encode("utf-8"), aad)
    return nonce.hex(), ciphertext.hex()


def decrypt_message(block):
    key = make_demo_key(block["sender"], block["recipient"])
    aad = f'{block["sender"]}:{block["recipient"]}'.encode()
    plaintext = AESGCM(key).decrypt(
        bytes.fromhex(block["nonce"]),
        bytes.fromhex(block["ciphertext"]),
        aad
    )
    return plaintext.decode("utf-8")


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "username" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


LAYOUT = """
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ title }} | CipherChain</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#0b1020;color:#edf2ff}
main{max-width:960px;margin:35px auto;padding:0 18px}.bar{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.logo{font-size:24px;font-weight:800}.logo span{color:#88a5ff}nav a{color:#b9c6e4;text-decoration:none;margin-left:14px}
.card{background:#141d33;border:1px solid #2b3957;border-radius:16px;padding:22px;margin:18px 0}
h1{font-size:clamp(27px,4vw,38px);margin:12px 0}h2{font-size:20px}p{color:#bdc9e2;line-height:1.55}
label{display:block;margin:13px 0 6px}input,textarea,select{width:100%;padding:12px;border-radius:9px;border:1px solid #394b70;background:#0b1327;color:#fff;font:inherit}
textarea{min-height:110px;resize:vertical}button,.button{display:inline-block;margin-top:14px;padding:11px 16px;border:0;border-radius:9px;background:#88a5ff;color:#071128;font-weight:700;text-decoration:none;cursor:pointer}
.button.secondary{background:#283858;color:#fff}.flash{background:#40263b;padding:12px;border-radius:9px;margin:12px 0}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}.stat{padding:15px;background:#0d1529;border:1px solid #2b3957;border-radius:10px}
.muted{color:#9daccb;font-size:13px}.ok{color:#91e3b4}.entry{padding:15px 0;border-top:1px solid #2b3957;overflow-wrap:anywhere}code{font-size:12px;overflow-wrap:anywhere}
</style></head><body><main>
<header class="bar"><div class="logo">◈ <span>Cipher</span>Chain</div><nav>
{% if session.get('username') %}<a href="{{ url_for('home') }}">Messages</a><a href="{{ url_for('ledger') }}">Blockchain</a><a href="{{ url_for('logout') }}">Log out</a>
{% else %}<a href="{{ url_for('login') }}">Login</a><a href="{{ url_for('register') }}">Register</a>{% endif %}
</nav></header>
{% for message in get_flashed_messages() %}<div class="flash">{{ message }}</div>{% endfor %}
{{ body|safe }}<p class="muted">CipherChain learning prototype — do not use for sensitive real-world communications.</p>
</main></body></html>
"""


def render_page(title, body, **kwargs):
    return render_template_string(LAYOUT, title=title, body=render_template_string(body, **kwargs))


@app.route("/")
def index():
    if session.get("username"):
        return redirect(url_for("home"))
    return render_page("Welcome", """
    <section class="card"><p>SECURE COMMUNICATION · BLOCKCHAIN · CRYPTOGRAPHY</p>
    <h1>Private messages.<br>Verifiable history.</h1>
    <p>CipherChain demonstrates authenticated encryption and a hash-linked message ledger.</p>
    <a class="button" href="{{ url_for('register') }}">Create account</a>
    <a class="button secondary" href="{{ url_for('login') }}">Login</a></section>
    <div class="grid"><section class="card"><h2>🔐 AES-GCM</h2><p>Encrypts message contents and detects ciphertext tampering.</p></section>
    <section class="card"><h2>⛓️ Blockchain ledger</h2><p>Every block links to the hash of the previous block.</p></section>
    <section class="card"><h2>✓ Integrity checks</h2><p>Check stored blocks for unexpected modifications.</p></section></div>
    """)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        users = read_json(USERS_FILE, {})
        if len(username) < 3 or len(username) > 32 or not username.replace("_", "").isalnum():
            flash("Username must be 3–32 characters using letters, numbers, or underscores.")
        elif len(password) < 10:
            flash("Password must be at least 10 characters.")
        elif username in users:
            flash("That username already exists.")
        else:
            users[username] = {"password_hash": generate_password_hash(password)}
            write_json(USERS_FILE, users)
            flash("Account created. Log in to continue.")
            return redirect(url_for("login"))
    return render_page("Register", """
    <section class="card"><h1>Create an account</h1><form method="post">
    <label>Username</label><input name="username" required minlength="3" maxlength="32" autocomplete="username">
    <label>Password (at least 10 characters)</label><input type="password" name="password" required minlength="10" autocomplete="new-password">
    <button>Create account</button></form></section>""")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        users = read_json(USERS_FILE, {})
        user = users.get(username)
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["username"] = username
            return redirect(url_for("home"))
        flash("Invalid username or password.")
    return render_page("Login", """
    <section class="card"><h1>Welcome back</h1><form method="post">
    <label>Username</label><input name="username" required autocomplete="username">
    <label>Password</label><input type="password" name="password" required autocomplete="current-password">
    <button>Login</button></form></section>""")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/home", methods=["GET", "POST"])
@login_required
def home():
    username = session["username"]
    users = read_json(USERS_FILE, {})
    if request.method == "POST":
        recipient = request.form.get("recipient", "").strip()
        message = request.form.get("message", "").strip()
        if recipient not in users:
            flash("Recipient account not found.")
        elif recipient == username:
            flash("Choose a different recipient.")
        elif not message:
            flash("Message cannot be empty.")
        elif len(message) > 5000:
            flash("Message must be no longer than 5,000 characters.")
        else:
            nonce, ciphertext = encrypt_message(username, recipient, message)
            block = add_block(username, recipient, nonce, ciphertext)
            flash(f"Message encrypted and saved in block #{block['index']}.")
            return redirect(url_for("home"))

    chain = get_chain()
    inbox = []
    for block in reversed(chain[1:]):
        if block.get("recipient") != username:
            continue
        try:
            message = decrypt_message(block)
        except Exception:
            message = "[Unable to decrypt: message may be corrupted or key changed]"
        inbox.append({
            "sender": block["sender"], "message": message, "index": block["index"],
            "date": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(block["timestamp"]))
        })
    valid, status = verify_chain(chain)
    recipients = sorted(name for name in users if name != username)
    return render_page("Messages", """
    <section class="card"><h1>Hello, {{ username }}</h1><div class="grid">
    <div class="stat"><span class="muted">Blocks in ledger</span><h2>{{ count }}</h2></div>
    <div class="stat"><span class="muted">Ledger integrity</span><h2 class="{{ 'ok' if valid else '' }}">{{ 'Valid' if valid else 'Failed' }}</h2></div>
    </div></section>
    <section class="card"><h2>Send a message</h2>
    {% if recipients %}<form method="post"><label>Recipient</label><select name="recipient" required>{% for name in recipients %}<option>{{ name }}</option>{% endfor %}</select>
    <label>Message</label><textarea name="message" required maxlength="5000" placeholder="Type your message"></textarea><button>Encrypt and send</button></form>
    {% else %}<p>Register a second user to test messaging. Log out, create the account, then log back in.</p>{% endif %}
    <p class="muted">Demo limitation: the server can derive the shared encryption key. This is not genuine end-to-end encryption.</p></section>
    <section class="card"><h2>Inbox</h2>{% if inbox %}{% for item in inbox %}<div class="entry"><strong>From {{ item.sender }}</strong> · Block {{ item.index }}<p>{{ item.message }}</p><span class="muted">{{ item.date }}</span></div>{% endfor %}{% else %}<p>No messages received yet.</p>{% endif %}</section>
    """, username=username, count=len(chain), valid=valid, recipients=recipients, inbox=inbox)


@app.route("/ledger")
@login_required
def ledger():
    chain = get_chain()
    valid, status = verify_chain(chain)
    blocks = []
    for block in reversed(chain):
        blocks.append({
            "index": block["index"], "sender": block["sender"], "recipient": block["recipient"],
            "date": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(block["timestamp"])),
            "hash": block["hash"], "previous_hash": block["previous_hash"],
            "ciphertext": block.get("ciphertext", "")
        })
    return render_page("Blockchain", """
    <section class="card"><h1>Blockchain ledger</h1><p class="{{ 'ok' if valid else '' }}">{{ status }}</p>
    <p class="muted">Encrypted payloads are stored in blocks, not plaintext message bodies.</p>
    <a class="button" href="{{ url_for('verify') }}">Verify chain</a></section>
    {% for block in blocks %}<section class="card"><h2>Block #{{ block.index }}</h2><p>{{ block.date }} · {{ block.sender }} → {{ block.recipient }}</p>
    <p><strong>Hash</strong><br><code>{{ block.hash }}</code></p><p><strong>Previous hash</strong><br><code>{{ block.previous_hash }}</code></p>
    {% if block.ciphertext %}<p><strong>Ciphertext</strong><br><code>{{ block.ciphertext[:180] }}{% if block.ciphertext|length > 180 %}…{% endif %}</code></p>{% endif %}</section>{% endfor %}
    """, valid=valid, status=status, blocks=blocks)


@app.route("/verify")
@login_required
def verify():
    valid, status = verify_chain()
    flash(status)
    return redirect(url_for("ledger"))


if __name__ == "__main__":
    get_chain()
    app.run(host="127.0.0.1", port=5000, debug=True)
